package edu.du.proj_g2e;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjG2eApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjG2eApplication.class, args);
    }

}
