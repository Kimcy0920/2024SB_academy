//package edu.du.proj_g2e.member;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.GetMapping;
//
//@Controller
//public class TestRegisterController {
//
//    @GetMapping("/regStep01")
//    public String regStep01() {
//        return "/auth/regStep01"; // regStep01.html 페이지를 반환
//    }
//
//    @GetMapping("/regStep02")
//    public String regStep02() {
//        return "/auth/regStep02"; // regStep02.html 페이지를 반환
//    }
//
//    @GetMapping("/regStep03_User")
//    public String regStep03User() {
//        return "/auth/regStep03_User"; // regStep03_User.html 페이지를 반환
//    }
//
//    @GetMapping("/regStep03_Check")
//    public String regStep03Check() {
//        return "/auth/regStep03_Check"; // regStep03_Check.html 페이지를 반환
//    }
//
//    @GetMapping("/regStep04")
//    public String regStep04() {
//        return "/auth/regStep04"; // regStep04.html 페이지를 반환
//    }
//}
//
