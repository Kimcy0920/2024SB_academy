package edu.du.proj_g2e.member.exception;

public class WrongIdPasswordException extends RuntimeException {

}
