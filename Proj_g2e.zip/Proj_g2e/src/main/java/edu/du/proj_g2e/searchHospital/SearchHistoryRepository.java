//package edu.du.proj_g2e.searchHospital;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface SearchHistoryRepository extends JpaRepository<SearchHistory, Long> {
//    SearchHistory findByQuery(String query);
//}